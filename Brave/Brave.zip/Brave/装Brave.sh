#!/bin/bash
# ============================================================
# 装Brave.sh —— Brave 浏览器一键安装 / 更新（Deepin 可用）
# 原理：从 GitHub 官方 Releases 下载 .deb 安装包，绕开
#       时通时断的 Brave 官方 apt 源。
# 用法：更新 = 重跑本脚本，覆盖安装即可。
# ============================================================
set -e

DL_DIR="$HOME/Downloads/brave-deb"
mkdir -p "$DL_DIR" && cd "$DL_DIR"

echo "==> 查询 Brave 最新版本……"
ASSET_URL=$(curl -sfL https://api.github.com/repos/brave/brave-browser/releases/latest \
  | grep -oP '"browser_download_url": "\K[^"]*brave-browser[^"]*amd64\.deb' \
  | head -n1)

if [ -z "$ASSET_URL" ]; then
  echo "!! 没拿到下载地址（GitHub API 连不上）。稍后再试，或手动打开："
  echo "   https://github.com/brave/brave-browser/releases/latest"
  exit 1
fi

echo "==> 下载地址：$ASSET_URL"
echo "==> 开始下载（16 线程。GitHub 源只肯开 2~3 条连接，所以优先走 gh-proxy 加速站）……"

if command -v aria2c >/dev/null 2>&1; then
  DL_TOOL="aria2"
  # 先走加速站（CDN 允许多连接），失败再退回直连
  if ! aria2c -x16 -s16 -c --console-log-level=warn --summary-interval=5 \
      "https://gh-proxy.com/${ASSET_URL}"; then
    echo "==> 加速站失败，换直连重试……"
    aria2c -x16 -s16 -c --console-log-level=warn --summary-interval=5 "$ASSET_URL"
  fi
else
  echo "==> 提示：未装 aria2，本次单线程下载会慢。"
  echo "==> 一次性补装（以后自动多线程提速）：sudo apt install -y aria2"
  if ! wget -c -q --show-progress "https://gh-proxy.com/${ASSET_URL}"; then
    echo "==> 加速站失败，换直连重试……"
    wget -c --show-progress "$ASSET_URL"
  fi
fi

echo "==> 安装 / 覆盖安装……"
sudo apt-get install -y ./*.deb

echo ""
echo "==> 完成！当前已装版本：$(brave-browser --version 2>/dev/null || echo '未检测到，请重试')"
